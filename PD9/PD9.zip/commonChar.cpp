#include<iostream>
using namespace std;
int commonChar(string ,string);
main()
{
    string s1,s2;
    int result;
    cout<<"Enter the string 1: ";
    cin>>s1;
    cout<<"Enter the string 2; ";
    cin>>s2;
    result = commonChar(s1,s2);
    cout<<"Common caharacters: "<<result;
}
int commonChar(string str1,string str2)
{
    int i,j,count1=0,count2=0,totalCount,common;
    while(str1[i]!='\0')
    {
        count1++;
        i++;
    }
    cout<<count1<<endl;
    while(str2[i]!='\0')
    {
        count2++;
        i++;
    }
    cout<<count2<<endl;
    totalCount = count1+count2;
    cout<<totalCount<<endl;
    for(i=0;i<count1;i++)
    {
        if(str1[i]==str2[i]||str1[i]==str2[i+1]||str1[i]==str2[i+2])
        {
            common+=1;
        }
    }
    return common;
}